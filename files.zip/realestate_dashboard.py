"""
부동산 경기 지표 분석 대시보드
================================
[선행] 경매낙찰률, 주택인허가, 전세가율, 주택가격전망지수(CSI), 수급지수
[동행] KB 매매·전세가 변동률(전국/서울/수도권/부산), 거래량
[후행] 미분양
데이터: Google News RSS 자동 파싱 (무료)
"""
import sys, io
if sys.stdout.encoding and sys.stdout.encoding.lower() != "utf-8":
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8", errors="replace")
    sys.stderr = io.TextIOWrapper(sys.stderr.buffer, encoding="utf-8", errors="replace")

import feedparser, requests, re, os
from datetime import datetime, timezone, timedelta

KST = timezone(timedelta(hours=9))

HEADERS = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/124.0.0.0 Safari/537.36",
    "Accept-Language": "ko-KR,ko;q=0.9",
    "Referer": "https://www.google.com/",
    "Cache-Control": "no-cache",
}


# ── 공통 유틸 ─────────────────────────────────────────────────────────────────
def safe_float(val, default=None):
    """안전한 float 변환 — 빈 문자열·None 처리"""
    try:
        if val is None or str(val).strip() == "":
            return default
        return float(str(val).replace(",", "").replace("%", "").strip())
    except Exception:
        return default

def safe_int(val, default=None):
    """안전한 int 변환"""
    try:
        if val is None or str(val).strip() in ("", ","):
            return default
        return int(str(val).replace(",", "").strip())
    except Exception:
        return default

def gn_feed(query, n=8):
    """Google News RSS 수집"""
    try:
        url  = f"https://news.google.com/rss/search?q={requests.utils.quote(query)}&hl=ko&gl=KR&ceid=KR:ko"
        resp = requests.get(url, headers=HEADERS, timeout=10)
        feed = feedparser.parse(resp.content)
        return [{
            "title":   e.get("title", ""),
            "link":    e.get("link", ""),
            "summary": e.get("summary", "") or e.get("description", "") or "",
            "date":    e.get("published", ""),
        } for e in feed.entries[:n]]
    except Exception as ex:
        print(f"    ER [{query[:25]}] {ex}")
        return []

def first_pct(text, pattern):
    """정규식으로 퍼센트 수치 첫 번째 추출, 범위 검증"""
    m = re.search(pattern, text)
    if not m:
        return None
    val = safe_float(m.group(1))
    return str(val) if val is not None else None

def arrow(val_str):
    v = safe_float(val_str)
    if v is None: return "→"
    return "▲" if v > 0 else ("▼" if v < 0 else "→")

def rate_color(val_str, up="#e53935", flat="#558b2f", down="#1565c0"):
    v = safe_float(val_str)
    if v is None: return "#888"
    return up if v > 0 else (down if v < 0 else flat)


# ══════════════════════════════════════════════════════════════════════════════
# A. KB부동산 주간 시황
# ══════════════════════════════════════════════════════════════════════════════
def get_kb_weekly():
    print("[A] KB부동산 주간 시황")
    r = {k: None for k in ["국전체","서울","수도권","부산","전세전국","전세서울",
                             "전세부산","매수우위","연속주수","방향","기준일"]}
    r["원문"] = []

    FEEDS = [
        "https://www.hankyung.com/feed/realestate",
        "https://www.yna.co.kr/rss/economy.xml",
        "https://www.asiae.co.kr/rss/all.htm",
        "https://www.mk.co.kr/rss/30100041/",
        "https://rss.donga.com/economy.xml",
        "https://www.sedaily.com/Rss/RealEstate",
        "https://www.ajunews.com/rss/economy.xml",
    ]
    KB_KEYS  = ["KB", "KB부동산", "국민은행", "매수우위지수", "주간 아파트"]
    EST_KEYS = ["아파트", "매매가격", "매매가"]

    # 패턴: 지역명 뒤 ▲▼ 기호 또는 숫자
    def p(region):
        return re.compile(
            rf'{region}\s*[▲△▼▽↑↓]?\s*([-+]?\d+\.\d+)\s*%'
        )
    RE = {
        "국전체":  re.compile(r'전국\s*[▲△▼▽↑↓]?\s*([-+]?\d+\.\d+)\s*%'),
        "서울":    p("서울"),
        "수도권":  p("수도권"),
        "부산":    p("부산"),
        "전세전국": re.compile(r'전세\s*[^%\d]{0,6}전국\s*[▲△▼▽]?\s*([-+]?\d+\.\d+)\s*%|'
                               r'전국\s*전세\s*[▲△▼▽]?\s*([-+]?\d+\.\d+)\s*%'),
        "매수우위": re.compile(r'매수우위지수\s*[^\d]*([\d.]+)'),
        "주수":    re.compile(r'(\d+)\s*주\s*(?:연속|째)'),
        "기준일":  re.compile(r'(\d{4})[년./]\s*(\d{1,2})[월./]\s*(\d{1,2})'),
    }

    for url in FEEDS:
        try:
            resp = requests.get(url, headers=HEADERS, timeout=8)
            feed = feedparser.parse(resp.content)
        except Exception:
            continue
        for e in feed.entries:
            title   = e.get("title", "")
            summary = e.get("summary", "") or e.get("description", "") or ""
            text    = title + " " + summary
            if not any(k in text for k in KB_KEYS): continue
            if not any(k in text for k in EST_KEYS): continue

            m_nat = RE["국전체"].search(text)
            if not m_nat: continue

            nat = safe_float(m_nat.group(1))
            if nat is None: continue

            r["국전체"] = str(nat)
            r["방향"]   = "상승" if nat > 0 else ("하락" if nat < 0 else "보합")

            for key in ["서울","수도권","부산"]:
                m = RE[key].search(text)
                if m: r[key] = str(safe_float(m.group(1)) or "")

            m_jeon = RE["전세전국"].search(text)
            if m_jeon:
                r["전세전국"] = str(safe_float(m_jeon.group(1) or m_jeon.group(2)) or "")

            m_buy = RE["매수우위"].search(text)
            if m_buy: r["매수우위"] = m_buy.group(1)

            m_wk = RE["주수"].search(text)
            if m_wk: r["연속주수"] = m_wk.group(1)

            m_dt = RE["기준일"].search(title + " " + (e.get("published","") or ""))
            if m_dt:
                r["기준일"] = f"{m_dt.group(1)}.{int(m_dt.group(2)):02d}.{int(m_dt.group(3)):02d}"

            r["원문"].append({"title": title, "link": e.get("link",""), "date": e.get("published","")[:10]})
            print(f"  파싱성공: 전국 {r['국전체']}% | 서울 {r['서울']}% | 부산 {r['부산']}% | {r['연속주수']}주")
            return r

    # RSS 실패 → Google News 시도
    for q in ["KB부동산 주간 아파트 매매가격 상승", "KB국민은행 주간 아파트 시황"]:
        for item in gn_feed(q, 5):
            text = item["title"] + " " + item["summary"]
            m_nat = RE["국전체"].search(text)
            if not m_nat: continue
            nat = safe_float(m_nat.group(1))
            if nat is None: continue
            r["국전체"] = str(nat)
            r["방향"]   = "상승" if nat > 0 else ("하락" if nat < 0 else "보합")
            m_s = RE["서울"].search(text)
            m_b = RE["부산"].search(text)
            m_w = RE["주수"].search(text)
            if m_s: r["서울"] = str(safe_float(m_s.group(1)) or "")
            if m_b: r["부산"] = str(safe_float(m_b.group(1)) or "")
            if m_w: r["연속주수"] = m_w.group(1)
            r["원문"].append(item)
            print(f"  파싱성공(GN): 전국 {r['국전체']}%")
            return r

    print("  데이터 없음 (미발표 또는 수집 실패)")
    return r


# ══════════════════════════════════════════════════════════════════════════════
# B. 경매 낙찰률
# ══════════════════════════════════════════════════════════════════════════════
def get_auction():
    print("[B] 경매 낙찰률")
    r = {"낙찰률": None, "낙찰가율": None, "건수": None, "원문": []}

    RE_RATE  = re.compile(r'낙찰률\s*[은는이가]?\s*([\d.]+)\s*%')
    RE_PRATE = re.compile(r'낙찰가율\s*[은는이가]?\s*([\d.]+)\s*%')
    RE_CNT   = re.compile(r'([\d,]+)\s*건\s*(?:낙찰|경매|응찰)')

    for q in ["아파트 경매 낙찰률 낙찰가율 월간", "법원 경매 아파트 낙찰"]:
        for item in gn_feed(q, 8):
            text = item["title"] + " " + item["summary"]
            if "낙찰" not in text: continue
            m_r  = RE_RATE.search(text)
            m_pr = RE_PRATE.search(text)
            m_c  = RE_CNT.search(text)
            # 낙찰률은 보통 20~60%, 낙찰가율은 80~130% 범위
            rate  = safe_float(m_r.group(1) if m_r else None)
            prate = safe_float(m_pr.group(1) if m_pr else None)
            if rate and 10 <= rate <= 80:
                r["낙찰률"] = str(rate)
            if prate and 50 <= prate <= 150:
                r["낙찰가율"] = str(prate)
            if m_c:
                r["건수"] = m_c.group(1)
            if r["낙찰률"] or r["낙찰가율"]:
                r["원문"].append(item)
                print(f"  파싱성공: 낙찰률 {r['낙찰률']}% | 낙찰가율 {r['낙찰가율']}%")
                return r
    print("  데이터 없음")
    return r


# ══════════════════════════════════════════════════════════════════════════════
# C. 주택 인허가
# ══════════════════════════════════════════════════════════════════════════════
def get_permit():
    print("[C] 주택 인허가")
    r = {"수치": None, "전년비": None, "기준월": None, "원문": []}

    RE_CNT   = re.compile(r'인허가\s*(?:물량|건수|실적)?\s*([\d,]+)\s*(?:만?\s*)?호')
    RE_YOY   = re.compile(r'전년\s*(?:동기)?\s*(?:대비)?\s*([-+]?\d+\.?\d*)\s*%')
    RE_MONTH = re.compile(r'(\d{4})년\s*(\d{1,2})월')

    for q in ["주택 인허가 실적 국토교통부", "주택인허가 만호 전년대비"]:
        for item in gn_feed(q, 6):
            text = item["title"] + " " + item["summary"]
            if "인허가" not in text: continue
            m_c = RE_CNT.search(text)
            m_y = RE_YOY.search(text)
            m_m = RE_MONTH.search(text)
            cnt = safe_int(m_c.group(1) if m_c else None)
            yoy = safe_float(m_y.group(1) if m_y else None)
            # 인허가는 보통 월 1만~10만호 범위
            if cnt and 1000 <= cnt <= 500000:
                r["수치"] = f"{cnt:,}"
                if yoy is not None and -100 <= yoy <= 200:
                    r["전년비"] = str(yoy)
                if m_m:
                    r["기준월"] = f"{m_m.group(1)}.{int(m_m.group(2)):02d}"
                r["원문"].append(item)
                print(f"  파싱성공: {r['수치']}호 (전년비 {r['전년비']}%)")
                return r
    print("  데이터 없음")
    return r


# ══════════════════════════════════════════════════════════════════════════════
# D. 전세가율
# ══════════════════════════════════════════════════════════════════════════════
def get_jeonse_ratio():
    print("[D] 전세가율")
    r = {"전국": None, "서울": None, "부산": None, "원문": []}

    # 전세가율은 보통 40~90% 범위
    RE_NAT  = re.compile(r'(?:전국|평균)\s*전세가율\s*[^\d]*([\d.]+)\s*%')
    RE_SEO  = re.compile(r'서울\s*(?:전세가율|전세)?\s*([\d.]+)\s*%')
    RE_BUS  = re.compile(r'부산\s*(?:전세가율)?\s*([\d.]+)\s*%')

    for q in ["전세가율 아파트 전국 KB", "아파트 전세가율 현황"]:
        for item in gn_feed(q, 8):
            text = item["title"] + " " + item["summary"]
            if "전세가율" not in text: continue
            m_n = RE_NAT.search(text)
            m_s = RE_SEO.search(text)
            m_b = RE_BUS.search(text)
            nat = safe_float(m_n.group(1) if m_n else None)
            seo = safe_float(m_s.group(1) if m_s else None)
            bus = safe_float(m_b.group(1) if m_b else None)
            # 전세가율 유효 범위: 40~90%
            if nat and 40 <= nat <= 90:
                r["전국"] = str(nat)
                if seo and 40 <= seo <= 90: r["서울"] = str(seo)
                if bus and 40 <= bus <= 90: r["부산"] = str(bus)
                r["원문"].append(item)
                print(f"  파싱성공: 전국 {r['전국']}% | 서울 {r['서울']}% | 부산 {r['부산']}%")
                return r
    print("  데이터 없음")
    return r


# ══════════════════════════════════════════════════════════════════════════════
# E. 소비자심리지수 (CSI) + 주택가격전망지수
# ══════════════════════════════════════════════════════════════════════════════
def get_csi():
    print("[E] 소비자심리지수(CSI)")
    r = {"CSI": None, "주택전망": None, "원문": []}

    # CSI는 보통 70~130 범위, 주택전망도 비슷
    RE_CSI  = re.compile(r'소비자심리지수\s*[은는이가]?\s*([\d.]+)')
    RE_HPCI = re.compile(r'주택가격전망(?:지수)?\s*[은는이가]?\s*([\d.]+)')

    for q in ["한국은행 소비자심리지수 주택가격전망지수", "CSI 소비자동향지수 주택전망"]:
        for item in gn_feed(q, 6):
            text = item["title"] + " " + item["summary"]
            m_c = RE_CSI.search(text)
            m_h = RE_HPCI.search(text)
            csi  = safe_float(m_c.group(1) if m_c else None)
            hpci = safe_float(m_h.group(1) if m_h else None)
            if csi and 50 <= csi <= 200:
                r["CSI"] = str(csi)
            if hpci and 50 <= hpci <= 200:
                r["주택전망"] = str(hpci)
            if r["CSI"] or r["주택전망"]:
                r["원문"].append(item)
                print(f"  파싱성공: CSI {r['CSI']} | 주택전망 {r['주택전망']}")
                return r
    print("  데이터 없음")
    return r


# ══════════════════════════════════════════════════════════════════════════════
# F. 매매·전세 수급지수 (한국부동산원)
# ══════════════════════════════════════════════════════════════════════════════
def get_supply_demand():
    print("[F] 수급동향")
    r = {"매매수급": None, "전세수급": None, "원문": []}

    # 수급지수 0~200, 기준 100
    RE_TRADE  = re.compile(r'매매\s*수급\s*(?:지수)?\s*[은는이가]?\s*([\d.]+)')
    RE_JEONSE = re.compile(r'전세\s*수급\s*(?:지수)?\s*[은는이가]?\s*([\d.]+)')

    for q in ["한국부동산원 매매수급지수 전세수급지수", "부동산원 수급동향 주간"]:
        for item in gn_feed(q, 6):
            text = item["title"] + " " + item["summary"]
            if "수급" not in text: continue
            m_t = RE_TRADE.search(text)
            m_j = RE_JEONSE.search(text)
            trade  = safe_float(m_t.group(1) if m_t else None)
            jeonse = safe_float(m_j.group(1) if m_j else None)
            # 수급지수 유효 범위: 50~180
            if trade and 50 <= trade <= 180:
                r["매매수급"] = str(trade)
            if jeonse and 50 <= jeonse <= 180:
                r["전세수급"] = str(jeonse)
            if r["매매수급"] or r["전세수급"]:
                r["원문"].append(item)
                print(f"  파싱성공: 매매 {r['매매수급']} | 전세 {r['전세수급']}")
                return r
    print("  데이터 없음")
    return r


# ══════════════════════════════════════════════════════════════════════════════
# G. 미분양
# ══════════════════════════════════════════════════════════════════════════════
def get_unsold():
    print("[G] 미분양")
    r = {"전국": None, "악성": None, "전년비": None, "기준월": None, "원문": []}

    RE_UNSOLD = re.compile(r'(?:전국\s*)?미분양\s*(?:주택\s*)?([\d,]+)\s*(?:만?\s*)?(?:가구|호|세대)')
    RE_악성   = re.compile(r'(?:준공후|악성)\s*미분양\s*([\d,]+)')
    RE_YOY    = re.compile(r'전년\s*(?:동기)?\s*(?:대비)?\s*([-+]?\d+\.?\d*)\s*%')
    RE_MONTH  = re.compile(r'(\d{4})년\s*(\d{1,2})월')

    for q in ["미분양 주택 현황 국토교통부 만호", "전국 미분양 감소 증가"]:
        for item in gn_feed(q, 6):
            text = item["title"] + " " + item["summary"]
            if "미분양" not in text: continue
            m_u = RE_UNSOLD.search(text)
            m_a = RE_악성.search(text)
            m_y = RE_YOY.search(text)
            m_m = RE_MONTH.search(text)
            cnt = safe_int(m_u.group(1) if m_u else None)
            악성 = safe_int(m_a.group(1) if m_a else None)
            yoy  = safe_float(m_y.group(1) if m_y else None)
            # 미분양 유효 범위: 1천~30만호
            if cnt and 1000 <= cnt <= 300000:
                r["전국"] = f"{cnt:,}"
                if 악성 and 악성 < cnt:
                    r["악성"] = f"{악성:,}"
                if yoy is not None and -100 <= yoy <= 500:
                    r["전년비"] = str(yoy)
                if m_m:
                    r["기준월"] = f"{m_m.group(1)}.{int(m_m.group(2)):02d}"
                r["원문"].append(item)
                print(f"  파싱성공: {r['전국']}호 (전년비 {r['전년비']}%)")
                return r
    print("  데이터 없음")
    return r


# ══════════════════════════════════════════════════════════════════════════════
# H. 주택 거래량
# ══════════════════════════════════════════════════════════════════════════════
def get_trade_vol():
    print("[H] 주택 거래량")
    r = {"거래량": None, "전년비": None, "기준월": None, "원문": []}

    RE_VOL   = re.compile(r'(?:매매\s*)?거래(?:량|건수)?\s*[은는이가]?\s*([\d,]+)\s*건')
    RE_YOY   = re.compile(r'전년\s*(?:동기)?\s*(?:대비)?\s*([-+]?\d+\.?\d*)\s*%')
    RE_MONTH = re.compile(r'(\d{4})년\s*(\d{1,2})월')

    for q in ["주택 매매 거래량 국토교통부 만건", "아파트 거래량 증가 감소"]:
        for item in gn_feed(q, 6):
            text = item["title"] + " " + item["summary"]
            if "거래" not in text: continue
            m_v = RE_VOL.search(text)
            m_y = RE_YOY.search(text)
            m_m = RE_MONTH.search(text)
            cnt = safe_int(m_v.group(1) if m_v else None)
            yoy = safe_float(m_y.group(1) if m_y else None)
            # 거래량 유효 범위: 1천~30만건
            if cnt and 1000 <= cnt <= 300000:
                r["거래량"] = f"{cnt:,}"
                if yoy is not None and -100 <= yoy <= 1000:
                    r["전년비"] = str(yoy)
                if m_m:
                    r["기준월"] = f"{m_m.group(1)}.{int(m_m.group(2)):02d}"
                r["원문"].append(item)
                print(f"  파싱성공: {r['거래량']}건 (전년비 {r['전년비']}%)")
                return r
    print("  데이터 없음")
    return r


# ══════════════════════════════════════════════════════════════════════════════
# I. 부산 지역 지표
# ══════════════════════════════════════════════════════════════════════════════
def get_busan():
    print("[I] 부산 지역 지표")
    r = {"아파트변동": None, "전세변동": None, "미분양": None, "원문": []}

    RE_APT  = re.compile(r'부산\s*(?:아파트\s*)?(?:매매)?\s*[▲△▼▽]?\s*([-+]?\d+\.\d+)\s*%')
    RE_JEON = re.compile(r'부산\s*전세\s*[▲△▼▽]?\s*([-+]?\d+\.\d+)\s*%')
    RE_UNSOL= re.compile(r'부산\s*미분양\s*([\d,]+)')

    for q in ["부산 아파트 매매 전세 동향 주간", "부산 부동산 시장 현황"]:
        for item in gn_feed(q, 8):
            text = item["title"] + " " + item["summary"]
            if "부산" not in text: continue
            m_a = RE_APT.search(text)
            m_j = RE_JEON.search(text)
            m_u = RE_UNSOL.search(text)
            apt  = safe_float(m_a.group(1) if m_a else None)
            jeon = safe_float(m_j.group(1) if m_j else None)
            unsol= safe_int(m_u.group(1) if m_u else None)
            if apt is not None and -5 <= apt <= 5:
                r["아파트변동"] = str(apt)
            if jeon is not None and -5 <= jeon <= 5:
                r["전세변동"] = str(jeon)
            if unsol and 100 <= unsol <= 50000:
                r["미분양"] = f"{unsol:,}"
            if r["아파트변동"] or r["전세변동"]:
                r["원문"].append(item)
                print(f"  파싱성공: 매매 {r['아파트변동']}% | 전세 {r['전세변동']}%")
                return r
    print("  데이터 없음")
    return r


# ══════════════════════════════════════════════════════════════════════════════
# 종합 분석
# ══════════════════════════════════════════════════════════════════════════════
def analyze(kb, jeonse, auction, csi, supply, unsold, trade):
    signals = []

    # KB 전국 매매가
    nat = safe_float(kb.get("국전체"))
    if nat is not None:
        d = "상승" if nat > 0 else ("하락" if nat < 0 else "보합")
        signals.append(("KB 전국 매매가", d, f"주간 {nat:+.2f}%"))
    # KB 부산
    bus = safe_float(kb.get("부산"))
    if bus is not None:
        d = "상승" if bus > 0 else ("하락" if bus < 0 else "보합")
        signals.append(("KB 부산 매매가", d, f"주간 {bus:+.2f}%"))

    # 전세가율
    jr = safe_float(jeonse.get("전국"))
    if jr is not None:
        if jr >= 70:   signals.append(("전세가율", "과열", f"{jr}% (적정 상한 70% 초과)"))
        elif jr >= 60: signals.append(("전세가율", "적정", f"{jr}% (적정 범위 60~70%)"))
        else:          signals.append(("전세가율", "침체", f"{jr}% (적정 하한 60% 미달)"))

    # 경매낙찰률
    ar = safe_float(auction.get("낙찰률"))
    if ar is not None:
        if ar >= 40:   signals.append(("경매낙찰률", "상승", f"{ar}% (고점 42% 근접)"))
        elif ar >= 34: signals.append(("경매낙찰률", "보합", f"{ar}% (정상 범위)"))
        else:          signals.append(("경매낙찰률", "침체", f"{ar}% (저점 32.4% 근접)"))

    # CSI
    hpci = safe_float(csi.get("주택전망"))
    if hpci is not None:
        if hpci >= 110: signals.append(("주택가격전망지수", "상승", f"{hpci} (낙관 — 100 초과)"))
        elif hpci >= 100:signals.append(("주택가격전망지수", "보합", f"{hpci} (장기평균 상회)"))
        else:           signals.append(("주택가격전망지수", "침체", f"{hpci} (장기평균 하회)"))

    # 수급지수
    sd = safe_float(supply.get("매매수급"))
    if sd is not None:
        if sd >= 110:  signals.append(("매매수급지수", "상승", f"{sd} (수요 우위)"))
        elif sd >= 90: signals.append(("매매수급지수", "보합", f"{sd} (균형)"))
        else:          signals.append(("매매수급지수", "침체", f"{sd} (공급 우위)"))

    # 미분양
    us = safe_int(str(unsold.get("전국") or "").replace(",",""))
    if us is not None:
        if us > 60000:  signals.append(("전국 미분양", "침체", f"{us:,}호 (위험 6.2만호 초과)"))
        elif us < 30000:signals.append(("전국 미분양", "상승", f"{us:,}호 (호황 3만호 미만)"))
        else:           signals.append(("전국 미분양", "보합", f"{us:,}호 (관찰 구간)"))

    # 거래량
    tv = safe_int(str(trade.get("거래량") or "").replace(",",""))
    tvr= safe_float(trade.get("전년비"))
    if tvr is not None:
        if tvr >= 20:   signals.append(("주택 거래량", "상승", f"전년비 +{tvr}% (회복세)"))
        elif tvr >= -10:signals.append(("주택 거래량", "보합", f"전년비 {tvr}%"))
        else:           signals.append(("주택 거래량", "침체", f"전년비 {tvr}% (위축)"))

    up   = sum(1 for _,d,_ in signals if d in ["상승","과열","적정"])
    down = sum(1 for _,d,_ in signals if d in ["침체","하락"])
    total= len(signals)

    if   total == 0:          verdict, vc = "데이터 수집 중",   "#888"
    elif up >= total * 0.7:   verdict, vc = "상승 우세",       "#c62828"
    elif up >= total * 0.55:  verdict, vc = "완만한 상승",     "#ef6c00"
    elif down >= total * 0.7: verdict, vc = "하락 우세",       "#1565c0"
    elif down >= total * 0.55:verdict, vc = "완만한 하락",     "#42a5f5"
    else:                     verdict, vc = "보합 / 혼조",     "#2e7d32"

    return signals, verdict, vc


# ══════════════════════════════════════════════════════════════════════════════
# HTML 생성
# ══════════════════════════════════════════════════════════════════════════════
def card(title, value, unit, sub, color, note="", news=None):
    """지표 카드"""
    if value:
        val_h = f'<span class="val" style="color:{color}">{value}</span><span class="unit"> {unit}</span>'
    else:
        val_h = '<span class="val na">—</span>'
    sub_h  = f'<div class="sub">{sub}</div>'   if sub  else ""
    note_h = f'<div class="note">{note}</div>' if note else ""
    news_h = ""
    for item in (news or [])[:2]:
        t = (item.get("title","") or "")[:52]
        l = item.get("link","#")
        d = (item.get("date","") or "")[:10]
        news_h += f'<div class="nref"><a href="{l}" target="_blank">📰 {t}</a> <span class="nd">{d}</span></div>'
    return f"""<div class="card">
  <div class="ctitle">{title}</div>
  <div class="cval">{val_h}</div>
  {sub_h}{note_h}
  <div class="cnews">{news_h}</div>
</div>"""

def sig_row(name, direction, desc):
    cm = {"상승":"#c62828","과열":"#880e4f","보합":"#e65100","적정":"#2e7d32","침체":"#1a237e","하락":"#0d47a1"}
    bm = {"상승":"▲ 상승","과열":"⚠ 과열","보합":"→ 보합","적정":"✔ 적정","침체":"▼ 침체","하락":"▼ 하락"}
    c = cm.get(direction,"#555")
    b = bm.get(direction, direction)
    return f"""<tr>
  <td class="sn">{name}</td>
  <td><span class="badge" style="background:{c}">{b}</span></td>
  <td class="sd">{desc}</td>
</tr>"""

def build_html(kb, permit, jeonse, auction, csi, supply, unsold, trade, busan):
    signals, verdict, vc = analyze(kb, jeonse, auction, csi, supply, unsold, trade)
    now   = datetime.now(KST)
    today = now.strftime("%Y년 %m월 %d일")
    upd   = now.strftime("%Y-%m-%d %H:%M KST")

    # 방향
    nat_val = safe_float(kb.get("국전체"))
    dir_icon = arrow(kb.get("국전체"))
    dir_color= rate_color(kb.get("국전체"))

    # KB 지역별 바
    regions = [("전국", "국전체"), ("서울", "서울"), ("수도권", "수도권"), ("부산", "부산")]
    kb_bar_items = ""
    for label, key in regions:
        v = kb.get(key)
        fv = safe_float(v)
        if fv is not None:
            ic = "▲" if fv > 0 else ("▼" if fv < 0 else "→")
            co = rate_color(v)
            kb_bar_items += f'<div class="kbi"><span class="kbr">{label}</span><span class="kbv" style="color:{co}">{ic} {fv:+.2f}%</span></div>'
        else:
            kb_bar_items += f'<div class="kbi"><span class="kbr">{label}</span><span class="kbv" style="color:#455a64">—</span></div>'

    # 연속주수
    wk_val = kb.get("연속주수")
    wk_dir = kb.get("방향","")
    kb_bar_items += f'<div class="kbi"><span class="kbr">{wk_dir} 연속</span><span class="kbv" style="color:{dir_color}">{wk_val or "—"}주</span></div>'
    kb_bar_items += f'<div class="kbi"><span class="kbr">기준일</span><span class="kbv" style="color:#78909c;font-size:13px">{kb.get("기준일") or "최신"}</span></div>'

    # 부산 매매가 (busan 또는 kb에서)
    busan_apt  = busan.get("아파트변동") or kb.get("부산")
    busan_jeon = busan.get("전세변동")   or kb.get("전세부산")

    html = f"""<!DOCTYPE html>
<html lang="ko">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>부동산 경기 지표 대시보드 {today}</title>
<style>
*{{box-sizing:border-box;margin:0;padding:0}}
body{{font-family:'Malgun Gothic',sans-serif;background:#0f1923;color:#cfd8dc;min-height:100vh;font-size:14px}}

/* 헤더 */
.hdr{{background:linear-gradient(135deg,#1a2942,#0d1f35);padding:22px 28px;border-bottom:2px solid #1e3a5f}}
.hdr h1{{font-size:20px;font-weight:700;color:#e8f4ff}}
.hdr h1 em{{font-size:12px;font-weight:400;color:#4fc3f7;margin-left:10px;font-style:normal}}
.upd{{font-size:11px;color:#546e7a;margin-top:4px}}

/* 종합판단 */
.vbar{{background:#132030;border-left:5px solid {vc};padding:14px 28px;display:flex;align-items:center;gap:16px}}
.vlabel{{font-size:11px;color:#546e7a;letter-spacing:1px}}
.vval{{font-size:28px;font-weight:700;color:{vc}}}
.vsub{{font-size:12px;color:#78909c;margin-top:2px}}

/* KB 바 */
.kbbar{{background:#0d1f35;padding:12px 28px;display:flex;gap:20px;flex-wrap:wrap;border-bottom:1px solid #1e3a5f}}
.kbi{{display:flex;flex-direction:column;align-items:center;min-width:72px}}
.kbr{{font-size:10px;color:#546e7a}}
.kbv{{font-size:17px;font-weight:700;margin-top:2px}}

/* 섹션 */
.sec{{padding:20px 28px}}
.stitle{{font-size:11px;font-weight:600;color:#4fc3f7;letter-spacing:1.5px;text-transform:uppercase;
         margin-bottom:14px;padding-bottom:6px;border-bottom:1px solid #1e3a5f}}

/* 카드 그리드 */
.grid{{display:grid;grid-template-columns:repeat(auto-fill,minmax(200px,1fr));gap:12px}}
.card{{background:#132030;border:1px solid #1e3a5f;border-radius:8px;padding:14px}}
.ctitle{{font-size:10px;color:#546e7a;letter-spacing:0.5px;margin-bottom:6px}}
.cval{{margin-bottom:4px}}
.val{{font-size:26px;font-weight:700}}
.unit{{font-size:12px;color:#546e7a}}
.val.na{{font-size:15px;color:#37474f}}
.sub{{font-size:11px;color:#78909c;margin-bottom:3px}}
.note{{font-size:10px;color:#455a64;font-style:italic}}
.cnews{{margin-top:6px}}
.nref{{font-size:10px;color:#455a64;margin-top:3px;line-height:1.4}}
.nref a{{color:#4fc3f7;text-decoration:none}}
.nref a:hover{{text-decoration:underline}}
.nd{{color:#37474f}}

/* 신호 테이블 */
.stbl{{width:100%;border-collapse:collapse}}
.stbl tr{{border-bottom:1px solid #1a2942}}
.stbl td{{padding:9px 8px;vertical-align:middle}}
.sn{{color:#90a4ae;width:160px;font-size:13px}}
.sd{{color:#546e7a;font-size:12px}}
.badge{{display:inline-block;padding:3px 9px;border-radius:4px;font-size:11px;font-weight:700;color:#fff}}

/* 부산 */
.bsbox{{background:#0a1e30;border:1px solid #1e3a5f;border-left:3px solid #4fc3f7;border-radius:8px;padding:14px}}
.bstitle{{font-size:11px;color:#4fc3f7;font-weight:600;margin-bottom:10px}}

/* 기준 박스 */
.refbox{{background:#0d1a26;border:1px solid #1a2942;border-radius:6px;padding:14px;
         font-size:11px;color:#455a64;line-height:1.9}}
.refbox b{{color:#607d8b}}

footer{{text-align:center;padding:18px;font-size:10px;color:#263238}}
</style>
</head>
<body>

<div class="hdr">
  <h1>부동산 경기 지표 대시보드 <em>Google News RSS 자동 수집 · 실시간 분석</em></h1>
  <div class="upd">업데이트: {upd}</div>
</div>

<!-- 종합 판단 -->
<div class="vbar">
  <div>
    <div class="vlabel">종합 경기 판단</div>
    <div class="vval">{verdict}</div>
    <div class="vsub">수집된 {len(signals)}개 지표 기반 자동 분석</div>
  </div>
</div>

<!-- KB 주간 시황 요약 -->
<div class="kbbar">{kb_bar_items}</div>

<!-- 선행지표 -->
<div class="sec">
  <div class="stitle">선행지표 (Leading Indicators)</div>
  <div class="grid">
    {card("① 경매 낙찰률",
        auction.get("낙찰률"), "%",
        f"낙찰가율 {auction.get('낙찰가율','—')}% | {auction.get('건수','—')}건",
        "#c62828" if safe_float(auction.get("낙찰률")) and safe_float(auction["낙찰률"])>=38
               else "#1565c0" if safe_float(auction.get("낙찰률")) and safe_float(auction["낙찰률"])<34
               else "#ef6c00",
        "아파트 32.4%(2023 저점)~42%(2021 고점)",
        auction.get("원문",[]))}

    {card("② 주택 인허가",
        permit.get("수치"), "호",
        f"전년비 {permit.get('전년비','—')}% | {permit.get('기준월','—')}",
        rate_color(permit.get("전년비")),
        "선행지표: 인허가→착공→준공 6~24개월 시차",
        permit.get("원문",[]))}

    {card("③ 전세가율",
        jeonse.get("전국"), "%",
        f"서울 {jeonse.get('서울','—')}% | 부산 {jeonse.get('부산','—')}%",
        "#c62828" if safe_float(jeonse.get("전국")) and safe_float(jeonse["전국"])>=70
               else "#1565c0" if safe_float(jeonse.get("전국")) and safe_float(jeonse["전국"])<60
               else "#2e7d32",
        "적정 60~70% | 70↑과열 | 60↓침체 (KB부동산)",
        jeonse.get("원문",[]))}

    {card("④ 주택가격전망지수",
        csi.get("주택전망"), "",
        f"소비자심리지수(CSI) {csi.get('CSI','—')}",
        "#c62828" if safe_float(csi.get("주택전망")) and safe_float(csi["주택전망"])>=110
               else "#2e7d32" if safe_float(csi.get("주택전망")) and safe_float(csi["주택전망"])>=100
               else "#1565c0",
        "100 이상=낙관 (한국은행, 장기평균 대비)",
        csi.get("원문",[]))}

    {card("⑤ 매매수급지수",
        supply.get("매매수급"), "",
        f"전세수급지수 {supply.get('전세수급','—')}",
        "#c62828" if safe_float(supply.get("매매수급")) and safe_float(supply["매매수급"])>=110
               else "#1565c0" if safe_float(supply.get("매매수급")) and safe_float(supply["매매수급"])<90
               else "#2e7d32",
        "100 이상=수요우위 | 0~200 범위 (한국부동산원)",
        supply.get("원문",[]))}
  </div>
</div>

<!-- 동행지표 -->
<div class="sec">
  <div class="stitle">동행지표 (Coincident Indicators)</div>
  <div class="grid">
    {card("KB 전국 매매가",
        (f"{nat_val:+.2f}" if nat_val is not None else None), "%",
        f"{kb.get('연속주수','—')}주 연속 {kb.get('방향','—')}",
        dir_color, "주간 변동률 (KB국민은행)", kb.get("원문",[]))}

    {card("KB 서울 매매가",
        (f"{safe_float(kb.get('서울')):+.2f}" if safe_float(kb.get('서울')) is not None else None), "%",
        f"수도권 {kb.get('수도권','—')}%",
        rate_color(kb.get("서울")), "주간 변동률 (KB국민은행)", [])}

    {card("KB 전국 전세가",
        (f"{safe_float(kb.get('전세전국')):+.2f}" if safe_float(kb.get('전세전국')) is not None else None), "%",
        f"서울 전세 {kb.get('전세서울','—')}%",
        rate_color(kb.get("전세전국")), "주간 전세 변동률 (KB국민은행)", [])}

    {card("주택 매매 거래량",
        trade.get("거래량"), "건",
        f"전년비 {trade.get('전년비','—')}% | {trade.get('기준월','—')}",
        rate_color(trade.get("전년비")),
        "국토교통부 실거래 신고 기준",
        trade.get("원문",[]))}
  </div>
</div>

<!-- 후행지표 -->
<div class="sec">
  <div class="stitle">후행지표 (Lagging Indicators)</div>
  <div class="grid">
    {card("전국 미분양",
        unsold.get("전국"), "호",
        f"준공후(악성) {unsold.get('악성','—')}호 | {unsold.get('기준월','—')}",
        "#1565c0" if safe_int(str(unsold.get("전국") or "").replace(",","")) and
                     safe_int(str(unsold.get("전국") or "").replace(",","")) > 60000
               else "#c62828" if safe_int(str(unsold.get("전국") or "").replace(",","")) and
                                  safe_int(str(unsold.get("전국") or "").replace(",","")) < 30000
               else "#ef6c00",
        "3만호↓호황 | 6.2만호↑위험 (국토교통부)",
        unsold.get("원문",[]))}
  </div>
</div>

<!-- 부산 지역 -->
<div class="sec">
  <div class="stitle">부산 지역 지표</div>
  <div class="bsbox">
    <div class="bstitle">🌊 부산 부동산 동향</div>
    <div class="grid" style="grid-template-columns:repeat(auto-fill,minmax(170px,1fr))">
      {card("부산 아파트 매매",
          (f"{safe_float(busan_apt):+.2f}" if safe_float(busan_apt) is not None else None), "%",
          "주간 변동률",
          rate_color(busan_apt),
          "KB부동산 기준", busan.get("원문",[])[:1])}

      {card("부산 전세가",
          (f"{safe_float(busan_jeon):+.2f}" if safe_float(busan_jeon) is not None else None), "%",
          "주간 전세 변동률",
          rate_color(busan_jeon), "KB부동산 기준", [])}

      {card("부산 미분양",
          busan.get("미분양"), "호",
          "부산 지역 미분양",
          "#888" if not busan.get("미분양") else "#ef6c00",
          "국토교통부 기준", [])}
    </div>
  </div>
</div>

<!-- 종합 신호 -->
<div class="sec">
  <div class="stitle">지표별 신호 분석</div>
  {'<p style="color:#37474f;font-size:13px">수집된 지표 없음 — 잠시 후 다시 실행하거나 로컬 PC에서 실행해 주세요.</p>' if not signals else f'''
  <table class="stbl"><tbody>
    {''.join(sig_row(n,d,desc) for n,d,desc in signals)}
  </tbody></table>'''}
</div>

<!-- 참고 기준 -->
<div class="sec">
  <div class="stitle">지표 해석 기준값</div>
  <div class="refbox">
    <b>경매 낙찰률:</b> 아파트 기준 42%(2021 고점) ~ 32.4%(2023 저점) · 전체 36%(2021) ~ 24.2%(2023)<br>
    <b>전세가율:</b> 60~70% 적정 · 70% 초과→매매가 상승 압력 · 60% 미만→하락 신호 (KB부동산)<br>
    <b>주택가격전망지수(CSI):</b> 100 이상=낙관 · 장기평균(2003~2019) 기준 (한국은행)<br>
    <b>매매·전세 수급지수:</b> 0~200 범위 · 100 초과=수요>공급 (한국부동산원)<br>
    <b>KB 매매·전세가격전망지수:</b> 0~200 범위 · 100 초과=상승 우위 (KB국민은행)<br>
    <b>전국 미분양:</b> 3만호↓=호황 · 6.2만호↑=위험 (국토교통부)<br>
    <b>선행→동행→후행 시차:</b> 인허가 발표 후 착공 3~6개월, 준공 12~24개월<br>
    <b>데이터 출처:</b> KB국민은행·한국부동산원·한국은행·국토교통부 보도자료 → Google News RSS 자동 파싱
  </div>
</div>

<footer>부동산 경기 지표 대시보드 · {upd} · 투자 결정의 참고 자료로만 활용하세요</footer>
</body></html>"""
    return html


# ══════════════════════════════════════════════════════════════════════════════
# 실행
# ══════════════════════════════════════════════════════════════════════════════
if __name__ == "__main__":
    print("=" * 52)
    print("부동산 경기 지표 수집 시작")
    print("=" * 52)

    kb     = get_kb_weekly()
    permit = get_permit()
    jeonse = get_jeonse_ratio()
    auction= get_auction()
    csi    = get_csi()
    supply = get_supply_demand()
    unsold = get_unsold()
    trade  = get_trade_vol()
    busan  = get_busan()

    print("\n" + "=" * 52)
    print("HTML 대시보드 생성")
    html = build_html(kb, permit, jeonse, auction, csi, supply, unsold, trade, busan)

    out = os.path.join(os.path.dirname(os.path.abspath(__file__)), "realestate_dashboard.html")
    with open(out, "w", encoding="utf-8") as f:
        f.write(html)

    print(f"[완료] {out}")
    print(f"\n수집 결과 요약:")
    print(f"  KB 전국  : {kb.get('국전체','—')}% | 서울 {kb.get('서울','—')}% | 부산 {kb.get('부산','—')}%")
    print(f"  경매낙찰률: {auction.get('낙찰률','—')}%  낙찰가율 {auction.get('낙찰가율','—')}%")
    print(f"  전세가율  : {jeonse.get('전국','—')}%")
    print(f"  주택전망  : {csi.get('주택전망','—')}")
    print(f"  매매수급  : {supply.get('매매수급','—')}")
    print(f"  미분양    : {unsold.get('전국','—')}호")
    print(f"  거래량    : {trade.get('거래량','—')}건")
